window.addEventListener('load', () => {

    const ul = document.getElementById('todo-list')
    const addBtn = document.getElementById('add-button')
    const createBlock = document.getElementById('create-form')
    const inputText = document.getElementById('titleInput')
    const printTitle = document.getElementById('printTitle')
    const saveButton = document.getElementById('saveButton')

    const todoInterface = function () {
        let eventExists = false
        const add = function (item) {

            document.dispatchEvent('addedEvent')
        }

        const cEvent = new Event('addedData')

        if (!eventExists) {
            document.addEventListener('addedData', () => { showData() })
            eventExists = true
        }

        return { add, }
    }

    const showData = async () => {
        ul.innerHTML = ''

        fetch('http://localhost:3000/todo', {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
            },
            // mode: 'no-cors',
        })
            // .then(response=>{console.log(response.json());return response})
            .then(response => response.json())
            .then(data => data.forEach((value, index) => {
                const li = document.createElement('li')
                li.innerHTML = value.title
                li.setAttribute('data-id', value.id)
                li.setAttribute('key', index)
                ul.appendChild(li)
            }))
            .catch(console.error)


    }

    const appendItemToTodo = async (itemText) => new Promise((resolve, reject) => {

        fetch('http://localhost:3000/todo', {
            method: 'post',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                title: itemText
            })
        })
            .then(response => response.json())
            .then(data => resolve(true))
            .catch(reject)

        // data.push({
        //     id: data.length,
        //     title: itemText,
        // })
        // resolve(true)
    })

    addBtn.addEventListener('click', event => {
        createBlock.classList.replace('d-none', 'd-block')
        // createBlock.classList.toggle('d-none')
    })

    inputText.addEventListener('input', event => {
        printTitle.innerText = event.target.value
    })

    saveButton.addEventListener('click', event => {
        event.preventDefault()

        appendItemToTodo(inputText.value)
            .then(result => result &&
                ((inputText.value = '') ||
                    (createBlock.classList.replace('d-block', 'd-none'))
                )
            )

        showData()
    })

    showData()

})