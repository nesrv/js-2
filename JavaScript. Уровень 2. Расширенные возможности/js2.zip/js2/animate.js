window.onload = e => {

    // function updateAnimate() {
    //     draw()
    // }
    // setInterval(updateAnimate, 1)

    // requestAnimationFrame(draw)

}

// const draw = () => {
//     document.getElementById('anim').style.left = (parseInt(document.getElementById('anim').style.left) + 5) + 'px'
//     if (true) {
//         requestAnimationFrame(draw)
//     }
// }