const sum = (a, b) => a + b

const sub = (a, b) => a - b

// module.exports = {sum, sub}

export {sum, sub}

export const pi = 3.14

export const f1 = ()=>{}

export default function f2(){}
