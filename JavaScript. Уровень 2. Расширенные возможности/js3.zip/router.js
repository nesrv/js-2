export function apiHome (req, res, data) {
    console.log(data);
    res.end('Hello, API')
}